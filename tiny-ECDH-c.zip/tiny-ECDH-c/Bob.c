////////////////////////////////////// ESP TEST //////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <MQTTClient.h>
#include "ecdh.h"
#include <openssl/evp.h>
#include <openssl/err.h>
#include <unistd.h> // Include this header for sleep function

#define MQTT_BROKER "tcp://192.168.101.142:1883"
#define CLIENT_ID "BobClient"
#define BOB_PUB_TOPIC "bobpk"
#define ALICE_SUB_TOPIC "alicepk"
#define BOB_DATA_TOPIC "data"
#define MAX_DATA_SIZE 1024
#define SHARED_SECRET_SIZE 32 // Adjust this based on your shared secret size

// Function prototypes
void mqtt_connect(MQTTClient client);
void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length);
void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length);
void print_key(const char *key_name, const uint8_t *key, size_t length);
void print_shared_secret(const uint8_t *secret, size_t length);
void aes_decrypt(const uint8_t *key, const uint8_t *ciphertext, int ciphertext_len, uint8_t *plaintext, int *plaintext_len);
void ecdh_bob(MQTTClient client, uint8_t *shared_secret);

void mqtt_connect(MQTTClient client) {
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username = "test";
    conn_opts.password = "test";

    printf("Connecting to MQTT broker...\n");
    int rc = MQTTClient_connect(client, &conn_opts);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to connect to MQTT broker, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    printf("Connected to MQTT broker.\n");
}

void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length) {
    int rc;
    MQTTClient_message *msg = NULL;
    char *topicName = NULL;
    int topicLen = 0;

    printf("Subscribing to topic: %s\n", topic);
    rc = MQTTClient_subscribe(client, topic, 1);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to subscribe to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }

    printf("Waiting to receive message on topic: %s\n", topic);
    rc = MQTTClient_receive(client, &topicName, &topicLen, &msg, 120000L);  // Increased to 120 seconds
    if (rc == MQTTCLIENT_SUCCESS && msg != NULL) {
        printf("Received message on topic '%s', message length: %d\n", topicName, msg->payloadlen);
        if (msg->payloadlen > MAX_DATA_SIZE) {
            fprintf(stderr, "Received message is too large (%d bytes)\n", msg->payloadlen);
            MQTTClient_freeMessage(&msg);
            MQTTClient_free(topicName);
            exit(EXIT_FAILURE);
        }
        *length = msg->payloadlen;
        memcpy(message, msg->payload, *length);
        MQTTClient_freeMessage(&msg);
        MQTTClient_free(topicName);
    } else {
        fprintf(stderr, "Failed to receive message, return code %d\n", rc);
    }
}

void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length) {
    printf("Publishing to topic: %s\n", topic);
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = (void *)message;
    pubmsg.payloadlen = length;
    pubmsg.qos = 1;
    pubmsg.retained = 0;

    int rc = MQTTClient_publishMessage(client, topic, &pubmsg, NULL);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to publish message to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }
    printf("Published to topic '%s': %zu bytes\n", topic, length);
}

void aes_decrypt(const uint8_t *key, const uint8_t *ciphertext, int ciphertext_len, uint8_t *plaintext, int *plaintext_len) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, NULL);

    int len;
    EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);
    *plaintext_len = len;

    EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    *plaintext_len += len;

    EVP_CIPHER_CTX_free(ctx);
}

void print_key(const char *key_name, const uint8_t *key, size_t length) {
    printf("%s: ", key_name);
    for (size_t i = 0; i < length; ++i) {
        printf("%02x", key[i]);
    }
    printf("\n");
}

void print_shared_secret(const uint8_t *secret, size_t length) {
    printf("Shared secret: ");
    for (size_t i = 0; i < length; ++i) {
        printf("%02x", secret[i]);
    }
    printf("\n");
}

void ecdh_bob(MQTTClient client, uint8_t *shared_secret) {
    uint8_t priv_b[ECC_PRV_KEY_SIZE];  // Bob's private key 'b'
    uint8_t pub_b[ECC_PUB_KEY_SIZE];   // Bob's public key 'P = b * G'
    uint8_t pub_a[ECC_PUB_KEY_SIZE];   // Alice's public key 'Q = a * G'

    // Generate Bob's private key and public key
    ecdh_generate_keys(pub_b, priv_b);
    printf("Bob's public key generated.\n");

    printf("Bob's public key:");
    for (int i = 0; i < ECC_PUB_KEY_SIZE; i++) {
        printf("%02x", pub_b[i]);
    }
    printf("\n");

    printf("Bob's private key:");
    for (int i = 0; i < ECC_PUB_KEY_SIZE; i++) {
        printf("%02x", priv_b[i]);
    }
    printf("\n");
    // Publish Bob's public key to Alice
    mqtt_publish(client, BOB_PUB_TOPIC, pub_b, ECC_PUB_KEY_SIZE);

    // Subscribe to Alice's public key
    mqtt_subscribe(client, ALICE_SUB_TOPIC, pub_a, &(size_t){ECC_PUB_KEY_SIZE});

        // Log Alice's private key
    printf("Alice's public key:");
    for (int i = 0; i < ECC_PUB_KEY_SIZE; i++) {
        printf("%02x", pub_a[i]);
    }
    printf("\n");
    // Compute shared secret: S = b * Q = b * (a * G)
    ecdh_shared_secret(priv_b, pub_a, shared_secret);
    printf("Shared secret computed by Bob.\n");

    // Print shared secret
    print_shared_secret(shared_secret, SHARED_SECRET_SIZE);

}

int main() {
    MQTTClient client;
    MQTTClient_create(&client, MQTT_BROKER, CLIENT_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    
    mqtt_connect(client);

    uint8_t shared_secret[SHARED_SECRET_SIZE];
    ecdh_bob(client, shared_secret);

    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);

    return 0;
}





//////////////////////////////////////// Manipulate files works ///////////////////////////////////////////////
// #include <stdlib.h>
// #include <stdio.h>
// #include <stdint.h>
// #include <string.h>
// #include <MQTTClient.h>
// #include "ecdh.h"
// #include <openssl/evp.h>
// #include <openssl/err.h>
// #include <unistd.h> // Include this header for sleep function

// #define MQTT_BROKER "tcp://localhost:1883"
// #define CLIENT_ID "BobClient"
// #define BOB_PUB_TOPIC "bobpk"
// #define ALICE_SUB_TOPIC "alicepk"
// #define BOB_DATA_TOPIC "data"
// #define MAX_DATA_SIZE 1024
// #define SHARED_SECRET_SIZE 32 // Adjust this based on your shared secret size
// #define BOB_READY_TOPIC "bobready" // Ensure topic matches with Alice's definition

// void mqtt_connect(MQTTClient client) {
//     MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
//     conn_opts.keepAliveInterval = 20;
//     conn_opts.cleansession = 1;
//     conn_opts.username = "test";
//     conn_opts.password = "test";

//     printf("Connecting to MQTT broker...\n");
//     int rc = MQTTClient_connect(client, &conn_opts);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to connect to MQTT broker, return code %d\n", rc);
//         exit(EXIT_FAILURE);
//     }
//     printf("Connected to MQTT broker.\n");
// }

// void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length) {
//     int rc;
//     MQTTClient_message *msg = NULL;
//     char *topicName = NULL;
//     int topicLen = 0;

//     printf("Subscribing to topic: %s\n", topic);
//     rc = MQTTClient_subscribe(client, topic, 1);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to subscribe to topic %s, return code %d\n", topic, rc);
//         exit(EXIT_FAILURE);
//     }

//     printf("Waiting to receive message on topic: %s\n", topic);
//     rc = MQTTClient_receive(client, &topicName, &topicLen, &msg, 20000); // 20 seconds timeout
//     if (rc == MQTTCLIENT_SUCCESS && msg) {
//         *length = msg->payloadlen;
//         memcpy(message, msg->payload, *length);
//         printf("Received %zu bytes from topic '%s'\n", *length, topic);
//         MQTTClient_freeMessage(&msg);
//         MQTTClient_free(topicName);
//     } else {
//         fprintf(stderr, "Failed to receive message from topic %s, return code %d\n", topic, rc);
//     }
// }

// void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length) {
//     printf("Publishing to topic: %s\n", topic);
//     MQTTClient_message pubmsg = MQTTClient_message_initializer;
//     pubmsg.payload = (void *)message;
//     pubmsg.payloadlen = length;
//     pubmsg.qos = 1;
//     pubmsg.retained = 0;

//     int rc = MQTTClient_publishMessage(client, topic, &pubmsg, NULL);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to publish message to topic %s, return code %d\n", topic, rc);
//         exit(EXIT_FAILURE);
//     }
//     printf("Published to topic '%s': %zu bytes\n", topic, length);
// }

// void aes_decrypt(const uint8_t *key, const uint8_t *ciphertext, size_t ciphertext_len, uint8_t *plaintext, int *plaintext_len) {
//     EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
//     EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, NULL);

//     int len;
//     EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);
//     *plaintext_len = len;

//     if (EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
//         fprintf(stderr, "Decryption failed: %s\n", ERR_error_string(ERR_get_error(), NULL));
//         *plaintext_len = -1; // Indicate failure
//     } else {
//         *plaintext_len += len;
//     }

//     EVP_CIPHER_CTX_free(ctx);
// }

// void ecdh_bob(MQTTClient client, uint8_t *shared_secret) {
//     uint8_t priv_b[ECC_PRV_KEY_SIZE];
//     uint8_t pub_b[ECC_PUB_KEY_SIZE];
//     uint8_t pub_a[ECC_PUB_KEY_SIZE];

//     ecdh_generate_keys(pub_b, priv_b);
//     printf("Bob's public key generated.\n");

//     mqtt_publish(client, BOB_PUB_TOPIC, pub_b, ECC_PUB_KEY_SIZE);
//     mqtt_subscribe(client, ALICE_SUB_TOPIC, pub_a, &(size_t){ECC_PUB_KEY_SIZE});
//     ecdh_shared_secret(priv_b, pub_a, shared_secret);
//     printf("Shared secret computed by Bob.\n");

//     const char *ready_msg = "Ready";
//     mqtt_publish(client, BOB_READY_TOPIC, (const uint8_t *)ready_msg, strlen(ready_msg) + 1);

//     uint8_t ciphertext[MAX_DATA_SIZE];
//     size_t ciphertext_length;
//     mqtt_subscribe(client, BOB_DATA_TOPIC, ciphertext, &ciphertext_length);

//     uint8_t plaintext[MAX_DATA_SIZE];
//     int plaintext_length;
//     aes_decrypt(shared_secret, ciphertext, ciphertext_length, plaintext, &plaintext_length);
    
//     if (plaintext_length >= 0) {
//         printf("Decrypted message: %.*s\n", plaintext_length, plaintext);
//     }
// }

// int main() {
//     MQTTClient client;
//     MQTTClient_create(&client, MQTT_BROKER, CLIENT_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
//     mqtt_connect(client);

//     uint8_t shared_secret[SHARED_SECRET_SIZE];
//     ecdh_bob(client, shared_secret);

//     MQTTClient_disconnect(client, 10000);
//     MQTTClient_destroy(&client);

//     return 0;
// }



//////////////////////////////////////// SIMPLE DATA THAT WORKS FINE /////////////////////////////////////
// #include <stdlib.h>
// #include <stdio.h>
// #include <stdint.h>
// #include <string.h>
// #include <MQTTClient.h>
// #include "ecdh.h"
// #include <openssl/evp.h>
// #include <openssl/err.h>
// #include <unistd.h> // Include this header for sleep function

// #define MQTT_BROKER "tcp://localhost:1883"
// #define CLIENT_ID "BobClient"
// #define BOB_PUB_TOPIC "bobpk"
// #define ALICE_SUB_TOPIC "alicepk"
// #define BOB_DATA_TOPIC "data"
// #define MAX_DATA_SIZE 1024
// #define SHARED_SECRET_SIZE 32 // Adjust this based on your shared secret size

// // Function prototypes
// void mqtt_connect(MQTTClient client);
// void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length);
// void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length);
// void print_key(const char *key_name, const uint8_t *key, size_t length);
// void print_shared_secret(const uint8_t *secret, size_t length);
// void aes_decrypt(const uint8_t *key, const uint8_t *ciphertext, int ciphertext_len, uint8_t *plaintext, int *plaintext_len);
// void ecdh_bob(MQTTClient client, uint8_t *shared_secret);

// void mqtt_connect(MQTTClient client) {
//     MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
//     conn_opts.keepAliveInterval = 20;
//     conn_opts.cleansession = 1;
//     conn_opts.username = "test";
//     conn_opts.password = "test";

//     printf("Connecting to MQTT broker...\n");
//     int rc = MQTTClient_connect(client, &conn_opts);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to connect to MQTT broker, return code %d\n", rc);
//         exit(EXIT_FAILURE);
//     }
//     printf("Connected to MQTT broker.\n");
// }

// void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length) {
//     int rc;
//     MQTTClient_message *msg = NULL;
//     char *topicName = NULL;
//     int topicLen = 0;

//     printf("Subscribing to topic: %s\n", topic);
//     rc = MQTTClient_subscribe(client, topic, 1);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to subscribe to topic %s, return code %d\n", topic, rc);
//         exit(EXIT_FAILURE);
//     }

//     printf("Waiting to receive message on topic: %s\n", topic);
//     rc = MQTTClient_receive(client, &topicName, &topicLen, &msg, 120000L);  // Increased to 120 seconds
//     if (rc == MQTTCLIENT_SUCCESS && msg != NULL) {
//         printf("Received message on topic '%s', message length: %d\n", topicName, msg->payloadlen);
//         if (msg->payloadlen > MAX_DATA_SIZE) {
//             fprintf(stderr, "Received message is too large (%d bytes)\n", msg->payloadlen);
//             MQTTClient_freeMessage(&msg);
//             MQTTClient_free(topicName);
//             exit(EXIT_FAILURE);
//         }
//         *length = msg->payloadlen;
//         memcpy(message, msg->payload, *length);
//         MQTTClient_freeMessage(&msg);
//         MQTTClient_free(topicName);
//     } else {
//         fprintf(stderr, "Failed to receive message, return code %d\n", rc);
//     }
// }

// void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length) {
//     printf("Publishing to topic: %s\n", topic);
//     MQTTClient_message pubmsg = MQTTClient_message_initializer;
//     pubmsg.payload = (void *)message;
//     pubmsg.payloadlen = length;
//     pubmsg.qos = 1;
//     pubmsg.retained = 0;

//     int rc = MQTTClient_publishMessage(client, topic, &pubmsg, NULL);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to publish message to topic %s, return code %d\n", topic, rc);
//         exit(EXIT_FAILURE);
//     }
//     printf("Published to topic '%s': %zu bytes\n", topic, length);
// }

// void aes_decrypt(const uint8_t *key, const uint8_t *ciphertext, int ciphertext_len, uint8_t *plaintext, int *plaintext_len) {
//     EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
//     EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, NULL);

//     int len;
//     EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);
//     *plaintext_len = len;

//     EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
//     *plaintext_len += len;

//     EVP_CIPHER_CTX_free(ctx);
// }

// void print_key(const char *key_name, const uint8_t *key, size_t length) {
//     printf("%s: ", key_name);
//     for (size_t i = 0; i < length; ++i) {
//         printf("%02x", key[i]);
//     }
//     printf("\n");
// }

// void print_shared_secret(const uint8_t *secret, size_t length) {
//     printf("Shared secret: ");
//     for (size_t i = 0; i < length; ++i) {
//         printf("%02x", secret[i]);
//     }
//     printf("\n");
// }

// void ecdh_bob(MQTTClient client, uint8_t *shared_secret) {
//     uint8_t priv_b[ECC_PRV_KEY_SIZE];  // Bob's private key 'b'
//     uint8_t pub_b[ECC_PUB_KEY_SIZE];   // Bob's public key 'P = b * G'
//     uint8_t pub_a[ECC_PUB_KEY_SIZE];   // Alice's public key 'Q = a * G'

//     // Generate Bob's private key and public key
//     ecdh_generate_keys(pub_b, priv_b);
//     printf("Bob's public key generated.\n");

//     // Publish Bob's public key to Alice
//     mqtt_publish(client, BOB_PUB_TOPIC, pub_b, ECC_PUB_KEY_SIZE);

//     // Subscribe to Alice's public key
//     mqtt_subscribe(client, ALICE_SUB_TOPIC, pub_a, &(size_t){ECC_PUB_KEY_SIZE});
    
//     // Compute shared secret: S = b * Q = b * (a * G)
//     ecdh_shared_secret(priv_b, pub_a, shared_secret);
//     printf("Shared secret computed by Bob.\n");

//     // Print shared secret
//     print_shared_secret(shared_secret, SHARED_SECRET_SIZE);
    
//     // Wait for Alice's data
//     uint8_t ciphertext[MAX_DATA_SIZE];
//     size_t ciphertext_len;

//     mqtt_subscribe(client, BOB_DATA_TOPIC, ciphertext, &ciphertext_len);

//     // Decrypt the received data
//     uint8_t plaintext[MAX_DATA_SIZE];
//     int plaintext_len;
//     aes_decrypt(shared_secret, ciphertext, ciphertext_len, plaintext, &plaintext_len);
//     plaintext[plaintext_len] = '\0'; // Null-terminate the plaintext

//     printf("Decrypted message from Alice: %s\n", plaintext);
// }

// int main() {
//     MQTTClient client;
//     MQTTClient_create(&client, MQTT_BROKER, CLIENT_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    
//     mqtt_connect(client);

//     uint8_t shared_secret[SHARED_SECRET_SIZE];
//     ecdh_bob(client, shared_secret);

//     MQTTClient_disconnect(client, 10000);
//     MQTTClient_destroy(&client);

//     return 0;
// }
