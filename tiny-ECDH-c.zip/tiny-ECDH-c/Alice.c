#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <MQTTClient.h>
#include <openssl/evp.h>
#include "ecdh.h"

#define MQTT_BROKER "tcp://localhost:1883"
#define CLIENT_ID "AliceClient"
#define ALICE_PUB_TOPIC "alicepk"
#define BOB_SUB_TOPIC "bobpk"
#define BOB_READY_TOPIC "bobready" // Ensure topic matches with Bob's definition
#define BOB_DATA_TOPIC "data"
#define MAX_DATA_SIZE 1024
#define SHARED_SECRET_SIZE 32 // Adjust this based on your shared secret size

void mqtt_connect(MQTTClient client) {
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username = "test";
    conn_opts.password = "test";

    printf("Connecting to MQTT broker...\n");
    int rc = MQTTClient_connect(client, &conn_opts);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to connect to MQTT broker, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    printf("Connected to MQTT broker.\n");
}

void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length) {
    printf("Subscribing to topic: %s\n", topic);
    int rc = MQTTClient_subscribe(client, topic, 1);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to subscribe to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }

    char *received_topic = NULL;
    int received_topic_len = 0;
    MQTTClient_message *received_msg = NULL;

    printf("Waiting for message from topic: %s\n", topic);
    rc = MQTTClient_receive(client, &received_topic, &received_topic_len, &received_msg, 20000); // 20 seconds timeout
    if (rc == MQTTCLIENT_SUCCESS && received_msg) {
        *length = received_msg->payloadlen;
        memcpy(message, received_msg->payload, *length);
        printf("Received %zu bytes from topic '%s'\n", *length, topic);
        MQTTClient_freeMessage(&received_msg);
        MQTTClient_free(received_topic);
    } else {
        fprintf(stderr, "Failed to receive message from topic %s, return code %d\n", topic, rc);
    }
}

void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length) {
    printf("Publishing to topic: %s\n", topic);
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = (void *)message;
    pubmsg.payloadlen = length;
    pubmsg.qos = 1;
    pubmsg.retained = 0;

    int rc = MQTTClient_publishMessage(client, topic, &pubmsg, NULL);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to publish message to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }
    printf("Published to topic '%s': %zu bytes\n", topic, length);
}

void aes_encrypt(const uint8_t *key, const uint8_t *plaintext, uint8_t *ciphertext, int *ciphertext_len) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, NULL);

    int len;
    EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, strlen((const char *)plaintext));
    *ciphertext_len = len;

    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    *ciphertext_len += len;

    EVP_CIPHER_CTX_free(ctx);
}

void read_file_data(const char *filename, uint8_t *buffer, size_t *length) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        fprintf(stderr, "Failed to open file %s\n", filename);
        exit(EXIT_FAILURE);
    }

    *length = fread(buffer, 1, MAX_DATA_SIZE, file);
    fclose(file);
    printf("Read %zu bytes from file %s\n", *length, filename);
}

void ecdh_alice(MQTTClient client, uint8_t *shared_secret) {
    uint8_t priv_a[ECC_PRV_KEY_SIZE];
    uint8_t pub_a[ECC_PUB_KEY_SIZE];
    uint8_t pub_b[ECC_PUB_KEY_SIZE];

    ecdh_generate_keys(pub_a, priv_a);
    printf("Alice's public key generated.\n");
    printf("Alice pvkey");
    for (size_t i = 0; i < ECC_PRV_KEY_SIZE; ++i) {
        printf(" %02X", priv_a[i]);
    }
    printf("\n");
    mqtt_subscribe(client, BOB_SUB_TOPIC, pub_b, &(size_t){ECC_PUB_KEY_SIZE});
    ecdh_shared_secret(priv_a, pub_b, shared_secret);
    printf("Shared secret computed by Alice.\n");

    mqtt_publish(client, ALICE_PUB_TOPIC, pub_a, ECC_PUB_KEY_SIZE);
    const char *ready_msg = "Ready";
    mqtt_publish(client, BOB_READY_TOPIC, (const uint8_t *)ready_msg, strlen(ready_msg) + 1);

    uint8_t ack_msg[4];
    size_t ack_length = sizeof(ack_msg);
    mqtt_subscribe(client, BOB_READY_TOPIC, ack_msg, &ack_length);

    uint8_t file_data[MAX_DATA_SIZE];
    size_t file_length;
    read_file_data("iot.txt", file_data, &file_length);

    uint8_t ciphertext[MAX_DATA_SIZE];
    int ciphertext_len;
    aes_encrypt(shared_secret, file_data, ciphertext, &ciphertext_len);
    
    mqtt_publish(client, BOB_DATA_TOPIC, ciphertext, ciphertext_len);
}

int main() {
    MQTTClient client;
    MQTTClient_create(&client, MQTT_BROKER, CLIENT_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    mqtt_connect(client);

    uint8_t shared_secret[SHARED_SECRET_SIZE];
    ecdh_alice(client, shared_secret);

    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);

    return 0;
}



////////////////////////////////////////////// SIMPLE DATA THAT WORKS /////////////////////
// #include <stdlib.h>
// #include <stdio.h>
// #include <stdint.h>
// #include <string.h>
// #include <MQTTClient.h>
// #include <openssl/evp.h>
// #include "ecdh.h"

// #define MQTT_BROKER "tcp://localhost:1883"
// #define CLIENT_ID "AliceClient"
// #define ALICE_PUB_TOPIC "alicepk"
// #define BOB_SUB_TOPIC "bobpk"
// #define BOB_READY_TOPIC "bob_ready" // New topic for Bob's readiness
// #define BOB_DATA_TOPIC "data"
// #define MAX_DATA_SIZE 1024
// #define SHARED_SECRET_SIZE 32 // Adjust this based on your shared secret size

// void mqtt_connect(MQTTClient client) {
//     MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
//     conn_opts.keepAliveInterval = 20;
//     conn_opts.cleansession = 1;
//     conn_opts.username = "test";
//     conn_opts.password = "test";

//     printf("Connecting to MQTT broker...\n");
//     int rc = MQTTClient_connect(client, &conn_opts);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to connect to MQTT broker, return code %d\n", rc);
//         exit(EXIT_FAILURE);
//     }
//     printf("Connected to MQTT broker.\n");
// }

// void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length) {
//     printf("Subscribing to topic: %s\n", topic);
//     int rc = MQTTClient_subscribe(client, topic, 1);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to subscribe to topic %s, return code %d\n", topic, rc);
//         exit(EXIT_FAILURE);
//     }

//     char *received_topic = NULL;
//     int received_topic_len = 0;
//     MQTTClient_message *received_msg = NULL;

//     printf("Waiting for message from topic: %s\n", topic);
//     rc = MQTTClient_receive(client, &received_topic, &received_topic_len, &received_msg, 20000); // 20 seconds timeout
//     if (rc == MQTTCLIENT_SUCCESS && received_msg) {
//         *length = received_msg->payloadlen;
//         memcpy(message, received_msg->payload, *length);
//         printf("Received %zu bytes from topic '%s'\n", *length, topic);
//         MQTTClient_freeMessage(&received_msg);
//         MQTTClient_free(received_topic);
//     } else {
//         fprintf(stderr, "Failed to receive message from topic %s, return code %d\n", topic, rc);
//     }
// }

// void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length) {
//     printf("Publishing to topic: %s\n", topic);
//     MQTTClient_message pubmsg = MQTTClient_message_initializer;
//     pubmsg.payload = (void *)message;
//     pubmsg.payloadlen = length;
//     pubmsg.qos = 1;
//     pubmsg.retained = 0;

//     int rc = MQTTClient_publishMessage(client, topic, &pubmsg, NULL);
//     if (rc != MQTTCLIENT_SUCCESS) {
//         fprintf(stderr, "Failed to publish message to topic %s, return code %d\n", topic, rc);
//         exit(EXIT_FAILURE);
//     }
//     printf("Published to topic '%s': %zu bytes\n", topic, length);
// }

// void aes_encrypt(const uint8_t *key, const uint8_t *plaintext, uint8_t *ciphertext, int *ciphertext_len) {
//     EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
//     EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, NULL);

//     int len;
//     EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, strlen((const char *)plaintext));
//     *ciphertext_len = len;

//     EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
//     *ciphertext_len += len;

//     EVP_CIPHER_CTX_free(ctx);
// }

// void ecdh_alice(MQTTClient client, uint8_t *shared_secret) {
//     uint8_t priv_a[ECC_PRV_KEY_SIZE];  // Alice's private key 'a'
//     uint8_t pub_a[ECC_PUB_KEY_SIZE];   // Alice's public key 'P = a * G'
//     uint8_t pub_b[ECC_PUB_KEY_SIZE];   // Bob's public key 'Q = b * G'

//     // Generate Alice's private key and public key
//     ecdh_generate_keys(pub_a, priv_a);
//     printf("Alice's public key generated.\n");

//     // Subscribe to Bob's public key
//     printf("Alice subscribing to Bob's public key...\n");
//     mqtt_subscribe(client, BOB_SUB_TOPIC, pub_b, &(size_t){ECC_PUB_KEY_SIZE});
    
//     // Compute shared secret: S = a * Q = a * (b * G)
//     ecdh_shared_secret(priv_a, pub_b, shared_secret);
//     printf("Shared secret computed by Alice.\n");

//     // Print shared secret
//     for (size_t i = 0; i < SHARED_SECRET_SIZE; ++i) {
//         printf("%02x", shared_secret[i]);
//     }
//     printf("\n");
    
//     // Publish Alice's public key
//     mqtt_publish(client, ALICE_PUB_TOPIC, pub_a, ECC_PUB_KEY_SIZE);

//     // Notify Bob that Alice is ready to send data
//     const char *ready_msg = "Ready";
//     mqtt_publish(client, BOB_READY_TOPIC, (const uint8_t *)ready_msg, strlen(ready_msg) + 1);

//     // Wait for acknowledgment from Bob
//     uint8_t ack_msg[4]; // buffer for acknowledgment message
//     size_t ack_length = sizeof(ack_msg);
//     mqtt_subscribe(client, BOB_READY_TOPIC, ack_msg, &ack_length);

//     // Prepare data to send (example: "Hello Bob!")
//     const uint8_t *data_to_send = (const uint8_t *)"Hello Bob!";
//     uint8_t ciphertext[MAX_DATA_SIZE];
//     int ciphertext_len;

//     // Encrypt data using AES
//     aes_encrypt(shared_secret, data_to_send, ciphertext, &ciphertext_len);

//     // Publish encrypted data to Bob
//     mqtt_publish(client, BOB_DATA_TOPIC, ciphertext, ciphertext_len);
// }

// int main() {
//     MQTTClient client;
//     MQTTClient_create(&client, MQTT_BROKER, CLIENT_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    
//     mqtt_connect(client);

//     uint8_t shared_secret[SHARED_SECRET_SIZE];
//     ecdh_alice(client, shared_secret);

//     MQTTClient_disconnect(client, 10000);
//     MQTTClient_destroy(&client);

//     return 0;
// }




// /*
//   Diffie-Hellman key exchange (without HMAC) aka ECDH_anon in RFC4492

//   1. Alice picks a (secret) random natural number 'a', calculates P = a * G and sends P to Bob.
//      'a' is Alice's private key. 
//      'P' is Alice's public key.

//   2. Bob picks a (secret) random natural number 'b', calculates Q = b * G and sends Q to Alice.
//      'b' is Bob's private key.
//      'Q' is Bob's public key.

//   3. Alice calculates S = a * Q = a * (b * G).

//   4. Bob calculates T = b * P = b * (a * G).

//   .. which are the same two values since multiplication in the field is commutative and associative.

//   T = S = the new shared secret.

//   Pseudo-random number generator inspired / stolen from: http://burtleburtle.net/bob/rand/smallprng.html

// */

// #include <assert.h>
// #include <stdio.h>
// #include <stdlib.h>
// #include <time.h>
// #include "ecdh.h"
// #include <time.h>
// #include <sys/time.h>

// /* pseudo random number generator with 128 bit internal state... probably not suited for cryptographical usage */
// typedef struct
// {
//   uint32_t a;
//   uint32_t b;
//   uint32_t c;
//   uint32_t d;
// } prng_t;

// static prng_t prng_ctx;

// static uint32_t prng_rotate(uint32_t x, uint32_t k)
// {
//   return (x << k) | (x >> (32 - k)); 
// }

// static uint32_t prng_next(void)
// {
//   uint32_t e = prng_ctx.a - prng_rotate(prng_ctx.b, 27); 
//   prng_ctx.a = prng_ctx.b ^ prng_rotate(prng_ctx.c, 17); 
//   prng_ctx.b = prng_ctx.c + prng_ctx.d;
//   prng_ctx.c = prng_ctx.d + e; 
//   prng_ctx.d = e + prng_ctx.a;
//   return prng_ctx.d;
// }

// static void prng_init(uint32_t seed)
// {
//   uint32_t i;
//   prng_ctx.a = 0xf1ea5eed;
//   prng_ctx.b = prng_ctx.c = prng_ctx.d = seed;

//   for (i = 0; i < 31; ++i) 
//   {
//     (void) prng_next();
//   }
// }





// static void ecdh_demo(void)
// {
//   static uint8_t puba[ECC_PUB_KEY_SIZE];
//   static uint8_t prva[ECC_PRV_KEY_SIZE];
//   static uint8_t seca[ECC_PUB_KEY_SIZE];
//   static uint8_t pubb[ECC_PUB_KEY_SIZE];
//   static uint8_t prvb[ECC_PRV_KEY_SIZE];
//   static uint8_t secb[ECC_PUB_KEY_SIZE];
//   uint32_t i;

//   /* 0. Initialize and seed random number generator */
//   static int initialized = 0;
//   if (!initialized)
//   {
//     prng_init((0xbad ^ 0xc0ffee ^ 42) | 0xcafebabe | 666);
//     initialized = 1;
//   }

//   /* 1. Alice picks a (secret) random natural number 'a', calculates P = a * g and sends P to Bob. */
//   for (i = 0; i < ECC_PRV_KEY_SIZE; ++i)
//   {
//     prva[i] = prng_next();
//   }
//   ecdh_generate_keys(puba, prva);

//   /* 2. Bob picks a (secret) random natural number 'b', calculates Q = b * g and sends Q to Alice. */
//   for (i = 0; i < ECC_PRV_KEY_SIZE; ++i)
//   {
//     prvb[i] = prng_next();
//   }
//   ecdh_generate_keys(pubb, prvb);

//   /* 3. Alice calculates S = a * Q = a * (b * g). */
//   ecdh_shared_secret(prva, pubb, seca);

//   /* 4. Bob calculates T = b * P = b * (a * g). */
//   ecdh_shared_secret(prvb, puba, secb);

//   /* 5. Assert equality, i.e. check that both parties calculated the same value. */
// //   for (i = 0; i < ECC_PUB_KEY_SIZE; ++i)
// //   {
// //     assert(seca[i] == secb[i]);
// //   }
// }


// /* WARNING: This is not working correctly. ECDSA is not working... */
// void ecdsa_broken()
// {
//   static uint8_t  prv[ECC_PRV_KEY_SIZE];
//   static uint8_t  pub[ECC_PUB_KEY_SIZE];
//   static uint8_t  msg[ECC_PRV_KEY_SIZE];
//   static uint8_t  signature[ECC_PUB_KEY_SIZE];
//   static uint8_t  k[ECC_PRV_KEY_SIZE];
//   uint32_t i;

//   srand(time(0));
//   srand(42);

//   for (i = 0; i < ECC_PRV_KEY_SIZE; ++i)
//   {
//     prv[i] = rand();
//     msg[i] = prv[i] ^ rand();
//     k[i] = rand();
//   }

// /* int ecdsa_sign(const uint8_t* private, const uint8_t* hash, uint8_t* random_k, uint8_t* signature);
//    int ecdsa_verify(const uint8_t* public, const uint8_t* hash, uint8_t* signature);                          */

//   ecdh_generate_keys(pub, prv);
//   /* No asserts - ECDSA functionality is broken... */
//   ecdsa_sign((const uint8_t*)prv, msg, k, signature);
//   ecdsa_verify((const uint8_t*)pub, msg, (const uint8_t*)signature); /* fails... */
// }


// struct timeval start, end, total, total_new = {0};

// int main(int argc, char* argv[])
// {
//   int i;
//   int ncycles = 1;
//   double total_sum = 0.0;
//   if (argc > 1)
//   {
//     ncycles = atoi(argv[1]);
//   }

//   for (i = 0; i < ncycles; ++i)
//   {
//     gettimeofday(&start, NULL);
//     ecdh_demo();
//     gettimeofday(&end, NULL);
//     timersub(&end, &start, &total);
//         if (i == 0) {
//             total_new = total;
//         } else {
//             timeradd(&total, &total_new, &total_new);
//         }
//     }
//     total_sum = ((double)total_new.tv_sec * 1000.0) + ((double)total_new.tv_usec / 1000.0);
//     total_sum /= ncycles;

//     printf("Key Pair Generation Time: %fms\n", total_sum);

//   return 0;
// }




// #include <stdio.h>
// #include <assert.h>
// #include <stdlib.h>
// #include <time.h>
// #include "ecdh.h"
// #include <sys/time.h>

// /* Pseudo random number generator with 128 bit internal state... probably not suited for cryptographic usage */
// typedef struct {
//     uint32_t a;
//     uint32_t b;
//     uint32_t c;
//     uint32_t d;
// } prng_t;

// static prng_t prng_ctx;

// static uint32_t prng_rotate(uint32_t x, uint32_t k) {
//     return (x << k) | (x >> (32 - k));
// }

// static uint32_t prng_next(void) {
//     uint32_t e = prng_ctx.a - prng_rotate(prng_ctx.b, 27);
//     prng_ctx.a = prng_ctx.b ^ prng_rotate(prng_ctx.c, 17);
//     prng_ctx.b = prng_ctx.c + prng_ctx.d;
//     prng_ctx.c = prng_ctx.d + e;
//     prng_ctx.d = e + prng_ctx.a;
//     return prng_ctx.d;
// }

// static void prng_init(uint32_t seed) {
//     uint32_t i;
//     prng_ctx.a = 0xf1ea5eed;
//     prng_ctx.b = prng_ctx.c = prng_ctx.d = seed;

//     for (i = 0; i < 31; ++i) {
//         (void) prng_next();
//     }
// }

// static void print_key(const char* name, const uint8_t* key, size_t size) {
//     printf("%s key:", name);
//     for (size_t i = 0; i < size; ++i) {
//         printf(" %02X", key[i]);
//     }
//     printf("\n");
// }

// static void print_shared_secret_base64(const uint8_t* shared_secret, size_t size) {
//     static const char base64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

//     printf("Shared secret key (Base64): ");
//     size_t i = 0;
//     while (i < size) {
//         // Encode the first 6 bits
//         printf("%c", base64_table[shared_secret[i] >> 2]);
//         // Encode the next 6 bits and the first 2 bits of the next byte
//         printf("%c", base64_table[((shared_secret[i] & 0x03) << 4) | ((shared_secret[i + 1] & 0xf0) >> 4)]);
//         // Encode the next 4 bits and the first 4 bits of the next byte
//         printf("%c", base64_table[((shared_secret[i + 1] & 0x0f) << 2) | ((shared_secret[i + 2] & 0xc0) >> 6)]);
//         // Encode the last 2 bits
//         printf("%c", base64_table[shared_secret[i + 2] & 0x3f]);

//         i += 3;
//     }
//     printf("\n");
// }

// static void ecdh_demo(void) {
//     static uint8_t puba[ECC_PUB_KEY_SIZE];
//     static uint8_t prva[ECC_PRV_KEY_SIZE];
//     static uint8_t seca[ECC_PUB_KEY_SIZE];
//     static uint8_t pubb[ECC_PUB_KEY_SIZE];
//     static uint8_t prvb[ECC_PRV_KEY_SIZE];
//     static uint8_t secb[ECC_PUB_KEY_SIZE];

//     /* Initialize and seed random number generator */
//     prng_init((0xbad ^ 0xc0ffee ^ 42) | 0xcafebabe | 666);

//     uint32_t i;

//     /* 1. Alice picks a (secret) random natural number 'a', calculates P = a * g and sends P to Bob. */
//     for (i = 0; i < ECC_PRV_KEY_SIZE; ++i) {
//         prva[i] = prng_next();
//     }
//     ecdh_generate_keys(puba, prva);
//     //print_key("Alice's", puba, ECC_PUB_KEY_SIZE);

//     /* 2. Bob picks a (secret) random natural number 'b', calculates Q = b * g and sends Q to Alice. */
//     for (i = 0; i < ECC_PRV_KEY_SIZE; ++i) {
//         prvb[i] = prng_next();
//     }
//     ecdh_generate_keys(pubb, prvb);
//     //print_key("Bob's", pubb, ECC_PUB_KEY_SIZE);

//     /* 3. Alice calculates S = a * Q = a * (b * g). */
//     ecdh_shared_secret(prva, pubb, seca);
//     //print_shared_secret_base64(seca, ECC_PUB_KEY_SIZE);
//     //printf("Size of Alice shared key: %zu bytes\n", (size_t)ECC_PUB_KEY_SIZE);

//     /* 4. Bob calculates T = b * P = b * (a * g). */
//     ecdh_shared_secret(prvb, puba, secb);
//     //print_shared_secret_base64(secb, ECC_PUB_KEY_SIZE);
//     //printf("Size of Bob shared key: %zu bytes\n", (size_t)ECC_PUB_KEY_SIZE);

//     /* 5. Assert equality, i.e. check that both parties calculated the same value. */
//     //for (i = 0; i < ECC_PUB_KEY_SIZE; ++i) {
//       //  assert(seca[i] == secb[i]);
//     //}

// }
// struct timeval start, end, total, total_new = {0};
// int main(int argc, char* argv[]) {
//     int i;
//     int ncycles = 1;
//     double total_sum = 0.0;
//     if (argc > 1) {
//         ncycles = atoi(argv[1]);
//     }

//     for (i = 0; i < ncycles; ++i) {
//         gettimeofday(&start, NULL);
//         ecdh_demo();
//         gettimeofday(&end, NULL);
//         timersub(&end, &start, &total);

//         if (i == 0) {
//             total_new = total;
//         } else {
//             timeradd(&total, &total_new, &total_new);
//         }
//     }
//     total_sum = ((double)total_new.tv_sec * 1000.0) + ((double)total_new.tv_usec / 1000.0);
//     total_sum /= ncycles;

//     printf("Key Pair Generation Time: %fms\n", total_sum);

    

//     return 0;
// }






// // /*
// //   Diffie-Hellman key exchange (without HMAC) aka ECDH_anon in RFC4492


// //   1. Alice picks a (secret) random natural number 'a', calculates P = a * G and sends P to Bob.
// //      'a' is Alice's private key. 
// //      'P' is Alice's public key.

// //   2. Bob picks a (secret) random natural number 'b', calculates Q = b * G and sends Q to Alice.
// //      'b' is Bob's private key.
// //      'Q' is Bob's public key.

// //   3. Alice calculates S = a * Q = a * (b * G).

// //   4. Bob calculates T = b * P = b * (a * G).

// //   .. which are the same two values since multiplication in the field is commutative and associative.

// //   T = S = the new shared secret.


// //   Pseudo-random number generator inspired / stolen from: http://burtleburtle.net/bob/rand/smallprng.html

// // */

// // #include <assert.h>
// // #include <stdio.h>
// // #include <stdlib.h>
// // #include <time.h>
// // #include "ecdh.h"



// // /* pseudo random number generator with 128 bit internal state... probably not suited for cryptographical usage */
// // typedef struct
// // {
// //   uint32_t a;
// //   uint32_t b;
// //   uint32_t c;
// //   uint32_t d;
// // } prng_t;

// // static prng_t prng_ctx;

// // static uint32_t prng_rotate(uint32_t x, uint32_t k)
// // {
// //   return (x << k) | (x >> (32 - k)); 
// // }

// // static uint32_t prng_next(void)
// // {
// //   uint32_t e = prng_ctx.a - prng_rotate(prng_ctx.b, 27); 
// //   prng_ctx.a = prng_ctx.b ^ prng_rotate(prng_ctx.c, 17); 
// //   prng_ctx.b = prng_ctx.c + prng_ctx.d;
// //   prng_ctx.c = prng_ctx.d + e; 
// //   prng_ctx.d = e + prng_ctx.a;
// //   return prng_ctx.d;
// // }

// // static void prng_init(uint32_t seed)
// // {
// //   uint32_t i;
// //   prng_ctx.a = 0xf1ea5eed;
// //   prng_ctx.b = prng_ctx.c = prng_ctx.d = seed;

// //   for (i = 0; i < 31; ++i) 
// //   {
// //     (void) prng_next();
// //   }
// // }





// // static void ecdh_demo(void)
// // {
// //   static uint8_t puba[ECC_PUB_KEY_SIZE];
// //   static uint8_t prva[ECC_PRV_KEY_SIZE];
// //   static uint8_t seca[ECC_PUB_KEY_SIZE];
// //   static uint8_t pubb[ECC_PUB_KEY_SIZE];
// //   static uint8_t prvb[ECC_PRV_KEY_SIZE];
// //   static uint8_t secb[ECC_PUB_KEY_SIZE];
// //   uint32_t i;

// //   /* 0. Initialize and seed random number generator */
// //   static int initialized = 0;
// //   if (!initialized)
// //   {
// //     prng_init((0xbad ^ 0xc0ffee ^ 42) | 0xcafebabe | 666);
// //     initialized = 1;
// //   }

// //   /* 1. Alice picks a (secret) random natural number 'a', calculates P = a * g and sends P to Bob. */
// //   for (i = 0; i < ECC_PRV_KEY_SIZE; ++i)
// //   {
// //     prva[i] = prng_next();
// //   }
// //   assert(ecdh_generate_keys(puba, prva));

// //   /* 2. Bob picks a (secret) random natural number 'b', calculates Q = b * g and sends Q to Alice. */
// //   for (i = 0; i < ECC_PRV_KEY_SIZE; ++i)
// //   {
// //     prvb[i] = prng_next();
// //   }
// //   assert(ecdh_generate_keys(pubb, prvb));

// //   /* 3. Alice calculates S = a * Q = a * (b * g). */
// //   assert(ecdh_shared_secret(prva, pubb, seca));

// //   /* 4. Bob calculates T = b * P = b * (a * g). */
// //   assert(ecdh_shared_secret(prvb, puba, secb));

// //   /* 5. Assert equality, i.e. check that both parties calculated the same value. */
// //   for (i = 0; i < ECC_PUB_KEY_SIZE; ++i)
// //   {
// //     assert(seca[i] == secb[i]);
// //   }
// // }


// // int main(int argc, char* argv[])
// // {
// //   int i;
// //   int ncycles = 1;

// //   if (argc > 1)
// //   {
// //     ncycles = atoi(argv[1]);
// //   }

// //   for (i = 0; i < ncycles; ++i)
// //   {
// //     ecdh_demo();
// //   }

// //   return 0;
// // }


