perfect the code are perfect now i just need to make them able to send any type of data (Images, files, iot data, etc...) and the data needs to be passed via terminal when i run the ./alice ....
this is Alice : #include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <MQTTClient.h>
#include <openssl/evp.h>
#include "ecdh.h"

#define MQTT_BROKER "tcp://192.168.101.142:1883"
#define CLIENT_ID "AliceClient"
#define ALICE_PUB_TOPIC "alicepk"
#define BOB_SUB_TOPIC "bobct"
#define BOB_DATA_TOPIC "bobdata"
#define MAX_DATA_SIZE 1024
#define SHARED_SECRET_SIZE ECC_PUB_KEY_SIZE

void mqtt_connect(MQTTClient client) {
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username = "test";
    conn_opts.password = "test";

    printf("Connecting to MQTT broker...\n");
    int rc = MQTTClient_connect(client, &conn_opts);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to connect to MQTT broker, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    printf("Connected to MQTT broker.\n");
}

void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length) {
    printf("Subscribing to topic: %s\n", topic);
    int rc = MQTTClient_subscribe(client, topic, 1);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to subscribe to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }

    char *received_topic = NULL;
    int received_topic_len = 0;
    MQTTClient_message *received_msg = NULL;

    printf("Waiting for message from topic: %s\n", topic);
    rc = MQTTClient_receive(client, &received_topic, &received_topic_len, &received_msg, 20000); // 20 seconds timeout
    if (rc == MQTTCLIENT_SUCCESS && received_msg) {
        *length = received_msg->payloadlen;
        memcpy(message, received_msg->payload, *length);
        printf("Received %zu bytes from topic '%s'\n", *length, topic);
        MQTTClient_freeMessage(&received_msg);
        MQTTClient_free(received_topic);
    } else {
        fprintf(stderr, "Failed to receive message from topic %s, return code %d\n", topic, rc);
    }
}

void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length) {
    printf("Publishing to topic: %s\n", topic);
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = (void *)message;
    pubmsg.payloadlen = length;
    pubmsg.qos = 1;
    pubmsg.retained = 0;

    int rc = MQTTClient_publishMessage(client, topic, &pubmsg, NULL);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to publish message to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }
    printf("Published to topic '%s': %zu bytes\n", topic, length);
}

void print_shared_secret(const uint8_t *shared_secret, size_t length) {
    printf("Shared secret: ");
    for (size_t i = 0; i < length; ++i) {
        printf("%02x", shared_secret[i]);
    }
    printf("\n");
}

void aes_encrypt(const uint8_t *key, const uint8_t *plaintext, uint8_t *ciphertext, int *ciphertext_len) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, NULL);

    int len;
    EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, strlen((const char *)plaintext));
    *ciphertext_len = len;

    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    *ciphertext_len += len;

    EVP_CIPHER_CTX_free(ctx);
}

void ecdh_alice(MQTTClient client, uint8_t *shared_secret) {
    uint8_t priv_a[ECC_PRV_KEY_SIZE];  // Alice's private key 'a'
    uint8_t pub_a[ECC_PUB_KEY_SIZE];   // Alice's public key 'P = a * G'
    uint8_t pub_b[ECC_PUB_KEY_SIZE];   // Bob's public key 'Q = b * G'

    // Generate Alice's private key and public key
    ecdh_generate_keys(pub_a, priv_a);
    printf("Alice's public key generated.\n");

    // Publish Alice's public key
    mqtt_publish(client, ALICE_PUB_TOPIC, pub_a, ECC_PUB_KEY_SIZE);

    // Subscribe to Bob's public key
    printf("Alice subscribing to Bob's public key...\n");
    mqtt_subscribe(client, BOB_SUB_TOPIC, pub_b, &(size_t){ECC_PUB_KEY_SIZE});

    // Compute shared secret: S = a * Q = a * (b * G)
    ecdh_shared_secret(priv_a, pub_b, shared_secret);
    printf("Shared secret computed by Alice.\n");
    print_shared_secret(shared_secret, SHARED_SECRET_SIZE);

    // Prepare data to send (example: "Hello Bob!")
    const uint8_t *data_to_send = (const uint8_t *)"Hello Bob!";
    uint8_t ciphertext[MAX_DATA_SIZE];
    int ciphertext_len;

    // Encrypt data using AES
    aes_encrypt(shared_secret, data_to_send, ciphertext, &ciphertext_len);

    // Publish encrypted data to Bob
    mqtt_publish(client, BOB_DATA_TOPIC, ciphertext, ciphertext_len);
}

int main() {
    MQTTClient client;
    MQTTClient_create(&client, MQTT_BROKER, CLIENT_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);

    mqtt_connect(client);

    uint8_t shared_secret[SHARED_SECRET_SIZE]; // Declare shared_secret here
    ecdh_alice(client, shared_secret); // Pass the shared_secret

    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);
    
    printf("Alice finished execution.\n");
    return EXIT_SUCCESS;
} 










and this is Bob : #include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <MQTTClient.h>
#include <openssl/evp.h>
#include "ecdh.h"

#define MQTT_BROKER "tcp://192.168.101.142:1883"
#define CLIENT_ID "BobClient"
#define BOB_PUB_TOPIC "bobct"
#define ALICE_SUB_TOPIC "alicepk"
#define BOB_DATA_TOPIC "bobdata"
#define MAX_DATA_SIZE 1024
#define SHARED_SECRET_SIZE ECC_PUB_KEY_SIZE

void mqtt_connect(MQTTClient client) {
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username = "test";
    conn_opts.password = "test";

    printf("Connecting to MQTT broker...\n");
    int rc = MQTTClient_connect(client, &conn_opts);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to connect to MQTT broker, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    printf("Connected to MQTT broker.\n");
}

void mqtt_subscribe(MQTTClient client, const char *topic, uint8_t *message, size_t *length) {
    printf("Subscribing to topic: %s\n", topic);
    int rc = MQTTClient_subscribe(client, topic, 1);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to subscribe to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }

    char *received_topic = NULL;
    int received_topic_len = 0;
    MQTTClient_message *received_msg = NULL;

    printf("Waiting for message from topic: %s\n", topic);
    rc = MQTTClient_receive(client, &received_topic, &received_topic_len, &received_msg, 20000); // 20 seconds timeout
    if (rc == MQTTCLIENT_SUCCESS && received_msg) {
        *length = received_msg->payloadlen;
        memcpy(message, received_msg->payload, *length);
        printf("Received %zu bytes from topic '%s'\n", *length, topic);
        MQTTClient_freeMessage(&received_msg);
        MQTTClient_free(received_topic);
    } else {
        fprintf(stderr, "Failed to receive message from topic %s, return code %d\n", topic, rc);
    }
}

void mqtt_publish(MQTTClient client, const char *topic, const uint8_t *message, size_t length) {
    printf("Publishing to topic: %s\n", topic);
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = (void *)message;
    pubmsg.payloadlen = length;
    pubmsg.qos = 1;
    pubmsg.retained = 0;

    int rc = MQTTClient_publishMessage(client, topic, &pubmsg, NULL);
    if (rc != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to publish message to topic %s, return code %d\n", topic, rc);
        exit(EXIT_FAILURE);
    }
    printf("Published to topic '%s': %zu bytes\n", topic, length);
}

void print_shared_secret(const uint8_t *shared_secret, size_t length) {
    printf("Shared secret: ");
    for (size_t i = 0; i < length; ++i) {
        printf("%02x", shared_secret[i]);
    }
    printf("\n");
}

void aes_decrypt(const uint8_t *key, const uint8_t *ciphertext, uint8_t *plaintext, int *plaintext_len) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, NULL);

    int len;
    EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, strlen((const char *)ciphertext));
    *plaintext_len = len;

    EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    *plaintext_len += len;

    EVP_CIPHER_CTX_free(ctx);
}

void ecdh_bob(MQTTClient client, uint8_t *shared_secret) {
    uint8_t priv_b[ECC_PRV_KEY_SIZE];  // Bob's private key 'b'
    uint8_t pub_b[ECC_PUB_KEY_SIZE];   // Bob's public key 'Q = b * G'
    uint8_t pub_a[ECC_PUB_KEY_SIZE];   // Alice's public key 'P = a * G'
    
    // Generate Bob's private key and public key
    ecdh_generate_keys(pub_b, priv_b);
    printf("Bob's public key generated.\n");

    // Subscribe to Alice's public key
    printf("Bob subscribing to Alice's public key...\n");
    mqtt_subscribe(client, ALICE_SUB_TOPIC, pub_a, &(size_t){ECC_PUB_KEY_SIZE});

    // Publish Bob's public key
    mqtt_publish(client, BOB_PUB_TOPIC, pub_b, ECC_PUB_KEY_SIZE);

    // Compute shared secret: S = b * P = b * (a * G)
    ecdh_shared_secret(priv_b, pub_a, shared_secret);
    printf("Shared secret computed by Bob.\n");
    print_shared_secret(shared_secret, SHARED_SECRET_SIZE);

    // Subscribe to Alice's encrypted data
    printf("Bob subscribing to Alice's encrypted data...\n");
    uint8_t ciphertext[MAX_DATA_SIZE];
    size_t ciphertext_len;
    mqtt_subscribe(client, BOB_DATA_TOPIC, ciphertext, &ciphertext_len);

    // Decrypt data using AES
    uint8_t decrypted_data[MAX_DATA_SIZE];
    int decrypted_data_len;
    aes_decrypt(shared_secret, ciphertext, decrypted_data, &decrypted_data_len);
    decrypted_data[decrypted_data_len] = '\0'; // Null-terminate string

    printf("Decrypted data from Alice: %s\n", decrypted_data);
}

int main() {
    MQTTClient client;
    MQTTClient_create(&client, MQTT_BROKER, CLIENT_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);

    mqtt_connect(client);

    uint8_t shared_secret[SHARED_SECRET_SIZE]; // Declare shared_secret here
    ecdh_bob(client, shared_secret); // Pass the shared_secret

    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);

    printf("Bob finished execution.\n");
    return EXIT_SUCCESS;
}
